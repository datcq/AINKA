(function () {
	$('#slider').on('ready', '.asset_11', function (e, el) {
		var slide =  $('#container', el);
		$('.aniCt',slide).fadeIn(function(){
			$('.board2',slide).bind('tapone', function(){
				$(this,slide).removeClass('act ff');
				$('.board1',slide).addClass('act');
			});
			$('.board1',slide).bind('tapone', function(){
				$(this,slide).removeClass('act ff');
				$('.board2',slide).addClass('act');
			});
			$('.plus',slide).bind('tapone', function(){
				$('.puScr',slide).fadeIn();
				$('.aniCt',slide).fadeOut();
			});		
			$('.close',slide).bind('tapone', function(){
				$('.puScr',slide).fadeOut();
				$('.aniCt',slide).fadeIn();
			});
			$('.col',slide).fadeIn(function(){
				setTimeout(function(){
					$('.col',slide).addClass('ani');
				},500);
			});	
		});
	});
})();
